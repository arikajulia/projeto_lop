/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 1 e 2
*/

// https://editor.p5js.org
var J=300;
var O=150;
function setup() {
  createCanvas(600,400);
}

function draw() {
  background(155);
  rect(100, 50, 75, 75);
  ellipse(J,O, 80, 80);
  if(keyIsDown  (DOWN_ARROW)) {
    O=O+5;
}
  if(keyIsDown (UP_ARROW)) {
    O=O-5;
}
  if(keyIsDown (RIGHT_ARROW)) {
    J=J+5;
}
  if(keyIsDown (LEFT_ARROW)) {
    J=J-5
  }
}