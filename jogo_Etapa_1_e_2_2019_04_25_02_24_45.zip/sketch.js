var J=300;
var O=150;
function setup() {
  createCanvas(600,400);
}

function draw() {
  background(155);
  rect(200, 50, 60, 60);
  ellipse(J,O, 80, 80);
  if(keyIsDown  (DOWN_ARROW)) {
    O=O+5;
}
  if(keyIsDown (UP_ARROW)) {
    O=O-5;
}
  if(keyIsDown (RIGHT_ARROW)) {
    J=J+5;
}
  if(keyIsDown (LEFT_ARROW)) {
    J=J-5
  }
}