/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 1 e 2
*/

// https://editor.p5js.org
var J=300;
var O=150;
function setup() {
  createCanvas(600,400);
}

function draw() {
  background(15);
  rect(100, 50, 75, 75);
  ellipse(J,O, 80, 80);
  if(keyIsDown  (DOWN_ARROW)) {
    O=O+5;
}
  if(keyIsDown (UP_ARROW)) {
    O=O-5;
}
  if(keyIsDown (RIGHT_ARROW)) {
    J=J+5;
}
  if(keyIsDown (LEFT_ARROW)) {
    J=J-5
  }
}
/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 3 e 4
*/
// https://editor.p5js.org
var x=500;
var y=400;
var xo=0;
var yo=50;
var yd=0;
var xd=0;
var estadodisparo = false;

function setup() {
  createCanvas(550, 550);
}

function draw() {
  background(15);
  rect (xo, yo, 65, 65);
  xo=xo+3;
  if (xo > 500) {
    xo = -random(100);
  }
  
  ellipse (x, y, 80, 80);
  if (keyIsDown (DOWN_ARROW)) {
  y = y+6;
}
if (keyIsDown (UP_ARROW)) {
  y = y -5;
}
if (keyIsDown (RIGHT_ARROW)) {
    x = x +5;
  }
if (keyIsDown (LEFT_ARROW)) { 
  x = x - 5; 
}
  x= x+3;
  if (x > 500) {
    x = 0;}
  if (keyIsDown(CONTROL) && estadodisparo == false ) {
    xd = x;
    yd = y;
    estadodisparo = true;
  }
  if ( estadodisparo ) {
  ellipse (xd, yd, 4, 4);
  yd = yd - 15;
    if (yd < 0) {
      estadodisparo = false;
    }
}
}