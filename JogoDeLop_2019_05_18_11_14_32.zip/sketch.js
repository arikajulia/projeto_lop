/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 1 e 2
*/

// https://editor.p5js.org
var J=300;
var O=150;
function setup() {
  createCanvas(600,400);
}

function draw() {
  background(15);
  rect(100, 50, 75, 75);
  ellipse(J,O, 80, 80);
  if(keyIsDown  (DOWN_ARROW)) {
    O=O+5;
}
  if(keyIsDown (UP_ARROW)) {
    O=O-5;
}
  if(keyIsDown (RIGHT_ARROW)) {
    J=J+5;
}
  if(keyIsDown (LEFT_ARROW)) {
    J=J-5
  }
}
/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 3 e 4
*/
// https://editor.p5js.org
var x=500;
var y=400;
var xo=0;
var yo=50;
var yd=0;
var xd=0;
var estadodisparo = false;

function setup() {
  createCanvas(550, 550);
}

function draw() {
  background(225);
  rect (xo, yo, 65, 65);
  xo=xo+3;
  if (xo > 500) {
    xo = -random(100);
  }
  
  ellipse (x, y, 80, 80);
  if (keyIsDown (DOWN_ARROW)) {
  y = y+6;
}
if (keyIsDown (UP_ARROW)) {
  y = y -5;
}
if (keyIsDown (RIGHT_ARROW)) {
    x = x +5;
  }
if (keyIsDown (LEFT_ARROW)) { 
  x = x - 5; 
}
  x= x+3;
  if (x > 500) {
    x = 0;}
  if (keyIsDown(CONTROL) && estadodisparo == false ) {
    xd = x;
    yd = y;
    estadodisparo = true;
  }
  if ( estadodisparo ) {
  ellipse (xd, yd, 4, 4);
  yd = yd - 15;
    if (yd < 0) {
      estadodisparo = false;
    }
}
}
/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 5 e 6
*/
// https://editor.p5js.org
var vidas = 3;
var pontos = 0;
var nivel = 1;

function setup() {
  createCanvas(550, 550);
}

function draw() {
  background(15);
  fill(0, 102, 153);
  textSize(20);
text('Vidas: '+vidas, 440, 60);
text('Pontos: '+pontos, 440, 30);
text('Nível: '+nivel, 10, 30);
  
  vidas = 2;
}

x = 300;
y = 400;
raio1 = 25;
xo = 150;//posição inicial eixo X
yo = 150;//posição inicial eixo Y
raio2 = 30;

function setup() {
  createCanvas(550, 550);
}

function draw() {
  background(15);
  fill(220)
  ellipse(x, y, 2*raio1, 2*raio1);
  if(keyIsDown(DOWN_ARROW)){
    y = y + 5;
  }
   if(keyIsDown(UP_ARROW)){
    y = y - 5;
  }
   if(keyIsDown(RIGHT_ARROW)){
    x = x + 5;
   }
   if(keyIsDown(LEFT_ARROW)){
    x = x - 5;
   }
  text('Inimigo', 120,110);//escreve o texto inimigo
  //inimigo
    fill(60);
    ellipse(xo, yo, 60, 60);
  //inimigo
  
 //----- placar de pontuação-----------
  fill(255,255,0);//cor em RGB amarelo
  textSize(25);
  text('---------- ', 420, 30);
  text('|Pontos| '+ pontos, 420, 50);
  text('----------', 420,70);//largura e altura
  //----- placar de pontuação-----------
  
  //----- placar de vida-----------
  fill(255,0,0);//cor em RGB veremlho
  textSize(25);//tamanho da fonte
  text('---------- ',300, 30);
  text('|Vidas| '+ vidas, 300, 50);
  text('----------', 300,70);//posição eixo Y e eixo X
  //----- placar de vida-----------
  
  if(dist(x, y, xo, yo) < raio1 + raio2) {
    vidas--;//subtrair 1 toda vez que está na distância
    pontos++;//adiciona 1  toda vez que está na distancia
    alert("Você morreu, total de vida é: ("+vidas+")");
    if (vidas == 2){// se  vida é igual a 2
      pontos = 20; //pontos recebe o valor de 20 
      x = 500;//posição inicial no eixo X
      y = 400;//posição inicial no eixo Y
    }
    if (vidas == 1){// se  vida é igual a 1
      pontos = 50;//pontos recebe o valor de 50 
      x = 500;
      y = 400;
    }
    if (vidas == 0){//quando não tiver mais vida
      pontos = 0;//retonar o valor inicial da variavel 
      vidas = 3;//retonar o valor inicial da variavel
      x = 500;
      y = 400;
      alert("Fim de jogo ");
      
    }
  }
}
