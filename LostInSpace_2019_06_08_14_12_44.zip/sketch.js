/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
*/
var x=230;//jogador
var y=350;
var xd=0;//disparo
var yd=0;
var estadodisparo = false;
var vidas = 3;
var pontos = 0;
var nivel = 0;
raio1 = 12;
raio2 = 33;
var vxo=[];//inimigo
var vyo=[];
var vtam=[];
var vVel=[];
var ajusteX = 30;
var ajusteY = 50;
var dificuldade = 500;
var qtIni= 4;
var tela = 1; 
var pontos = 0; 

let morte = false;
let vencer = false;
let cenario; 
let nave;
let asteroide;
let projetil;

function preload() {  
 projetil = loadImage('https://raw.githubusercontent.com/ect-info/lop/master/Sprites/GalagianArtwork/Sprites%20Extras/projectiles/shot12.png');
  asteroide = loadImage('https://raw.githubusercontent.com/ect-info/lop/master/Sprites/GalagianArtwork/Sprites%20Extras/asteroids/asteroid_40.png');
  cenario = loadImage('https://live.staticflickr.com/65535/48001253391_22a06f10ca_k.jpg');
   nave  = loadImage('https://raw.githubusercontent.com/ect-info/lop/master/Sprites/Personagens/Naves/200%20sprites%20de%20naves/ship_10.png');
}

function setup() { 
   createCanvas(600,550);
   frameRate (30);
//ETAPA 7//
   for (var repetirIni=0; repetirIni <qtIni; repetirIni++) {
    vxo[repetirIni] = random(0,600);
    vyo[repetirIni] = random(0,600);
    vtam[repetirIni] = (2,60);
    vVel [repetirIni] = random(1,10); 
  }
 }
function draw() {
  if ((morte != true) || (vencer == true)){
    background(cenario);
  if(nivel == 0){
    background(0); 
    textSize(50);
    fill('#FF00FF');
    text('LOST IN SPACE', 120, 300);
    textSize(30) 
    text('(Pressione ENTER para jogar)', 100, 330 )
    if(keyIsDown(32)){
     nivel= 1; 
  }
}
//ETAPA 8// 
  for (var repetirIni=0; repetirIni<qtIni; repetirIni++) {  
    if(pontos > dificuldade){
        nivel++;
        dificuldade = dificuldade + 500;  
}  
if(nivel ==1){
image(asteroide,vxo[repetirIni] + ajusteX , vyo [repetirIni] + ajusteY, vtam[repetirIni], vtam[repetirIni])
    vyo[repetirIni] = vyo[repetirIni]+ vVel[repetirIni];
//ETAPA 6//
    if (dist(x, y, vxo[repetirIni], vyo[repetirIni]) < raio1 + raio2){
      vidas--;
      vyo[repetirIni] = - random(0,600);//destroi o asteroide
    if (vidas == 0){
          morte = true;
    }
  }
}
//ETAPA 8//
if(nivel == 2){
image(asteroide, vxo[repetirIni]+ ajusteX, vyo [repetirIni]+ ajusteY, vtam[repetirIni], vtam[repetirIni])
vyo[repetirIni] = vyo[repetirIni]+Math.random(vVel[repetirIni])*10;

//ETAPA 6//
  if (dist(x, y, vxo[repetirIni], vyo[repetirIni]) < raio1 + raio2) {
    vidas--;
    vyo[repetirIni] = - random(0,600);
      if (vidas == 0){
        background(0);
      morte = true;
    }
  }
}

//ETAPA 8//
if(nivel == 3){
image(asteroide,vxo[repetirIni]+ ajusteX,vyo [repetirIni]+ ajusteY, vtam[repetirIni]-10, vtam[repetirIni]-10 )
    vyo[repetirIni] = vyo[repetirIni]+Math.random(vVel[repetirIni])*20;
  //ETAPA 6//  
  if (dist(x, y, vxo[repetirIni], vyo[repetirIni]) < raio1 + raio2) {
      vidas--;
    vyo[repetirIni] = - random(0,600);//destroi o asteroide
      if (vidas == 0){
        background(0);
          morte = true;
    }
  }
}
    
//ETAPA 8//
if(nivel == 4){
  image(asteroide,vxo[repetirIni]+ ajusteX, vyo [repetirIni]+ ajusteY, vtam[repetirIni]-20, vtam[repetirIni]-20 )
    vyo[repetirIni] = vyo[repetirIni]+Math.random(vVel[repetirIni])*25;
  //ETAPA 6//
    if (dist(x, y, vxo[repetirIni], vyo[repetirIni]) < raio1 + raio2) {
      x=230;
      y=350;
      vidas--;
      vyo[repetirIni] = - random(0,600);//destroi o asteroide
      if (vidas == 0){
        background(0);
          morte = true;
    }
  } 
}

//ETAPA 8//
if(nivel == 5){
 image(asteroide,vxo[repetirIni]+ ajusteX, vyo[repetirIni]+ ajusteY, vtam[repetirIni]-25, vtam[repetirIni]-25 )
vyo[repetirIni] = vyo[repetirIni]+Math.random(vVel[repetirIni])*22;
    //ETAPA 6//
    if (dist(x, y, vxo[repetirIni], vyo[repetirIni]) < raio1 + raio2) {
      x=230;
      y=350;
      vidas--;
      vyo[repetirIni] = - random(0,600);
      if (vidas == 0){
      background(0);
          morte = true;
      x =250;
      y =340;
      vyo[repetirIni] = - random(0,0);
    }
  }
}

//ETAPA 8//
if((nivel == 6)){
          background(0);
          vencer = true;
      x =250;
      y =340;
      vyo[repetirIni] = - random(0,0);
}
//ETAPA 3//
  if (vyo[repetirIni] > 600) {
    vxo[repetirIni] = random(0,600);
    vyo[repetirIni] = - random(0,600);
    }
    if (estadodisparo) {
      if (dist(vxo[repetirIni], vyo[repetirIni], xd, yd) < raio1 + raio2) {
      vxo[repetirIni] = random(0,600);
      vyo[repetirIni] = -random(0,600);
      pontos = pontos+50;
    }
  } 
}
  
//ETAPA 1//
if(morte == false){
      image(nave, x, y, 10*raio1, 10*raio1);
    }
if((vencer  == true) && (nivel == 6)){
    background(cenario);
    fill('#FF00FF');
    textSize(50);
    text('Você venceu, parabéns :)',30,300 );
    }
if((vencer == false) && (morte == true)){// Se não vencer e morrer
    fill(255,0,0);
    background(cenario);
    fill('#FF00FF');
    textSize(90);
    text('GAME OVER', 20, 300 ); 
    textSize(40) 
    text('Tente novamente!', 130, 340 )
    }
    
//ETAPA 2//
if(keyIsDown(DOWN_ARROW)){
    y = y + 5;
  }
if(keyIsDown(UP_ARROW)){
    y = y - 5;
  }
if(keyIsDown(RIGHT_ARROW)){
    x = x + 5;
   }
if(keyIsDown(LEFT_ARROW)){
    x = x - 5;
   }
if (x > 500) {
    x = 0;
  }
if (x < 0) {
    x = 500;
  }
if((morte == false) || (vencer == false)){
//ETAPA 4//
if (keyIsDown(32) && estadodisparo == false ) {
    xd = x;
    yd = y;
    estadodisparo = true;
  }
if ( estadodisparo ) {
       image(projetil, xd +40 , yd, 10*3 , 10*3);
    yd = yd - 15;
if (yd < 0) {
      estadodisparo = false;
    }
  }
  
//ETAPA 5//
  //----- placar de pontuação-------
  fill("#FF00FF");//cor em RGB amarelo
  textSize(25);
  text('---------- ', 10, 30);
  text('|Pontos| '+ pontos, 10, 50);
  text('----------', 10,70);//largura e altura
  //----- placar de pontuação-----------
  
  //----- placar de vida-----------
  fill(255,0,0);//cor em RGB vermelho
  textSize(25);
  text('---------- ',250, 30);
  text('|Vidas| '+ vidas, 250, 50);
  text('----------', 250,70);
  
  //----- placar do nível-----------
  fill(70,130,180);//cor em RGB vermelho
  textSize(25);
  text('---------- ',470, 30);
  text('| Nivel | '+ nivel, 470, 50);
  text('----------', 470,70);
  //----- placar do nível-----------
  fill(220,220,220);//cor em RGB vermelho   
  }
  }
}