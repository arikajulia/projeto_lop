/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 1 e 2
*/

// https://editor.p5js.org
var J=300;
var O=150;
function setup() {
  createCanvas(600,400);
}

function draw() {
  background(15);
  rect(100, 50, 75, 75);
  ellipse(J,O, 80, 80);
  if(keyIsDown  (DOWN_ARROW)) {
    O=O+5;
}
  if(keyIsDown (UP_ARROW)) {
    O=O-5;
}
  if(keyIsDown (RIGHT_ARROW)) {
    J=J+5;
}
  if(keyIsDown (LEFT_ARROW)) {
    J=J-5
  }
}
/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 3 e 4
*/
// https://editor.p5js.org
var x=100;
var y=400;
var xo=0;
var yo=50;
var yd=0;
var xd=0;
var estadoDisparo= false

function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(15);

rect(xo, yo, 50, 50)
  xo=xo+5
  if(xo > 800){
    xo=-random(300);
  }

ellipse(x, y, 80, 80)
  x=x+5
  if(x > width)
  x=0
  if(keyIsDown(UP_ARROW) && estadoDisparo == false){
  xd=x
  yd=y
  estadoDisparo= true;
  }
  if(estadoDisparo){
    ellipse(xd, yd, 10,10)
    yd=yd-15
    if(yd<0)
      estadoDisparo=false;
  }
}