/*
  Equipe:
  Árika Júlia Heydmann Gurgel- Subturma C (Líder)
  Evelyn Beatriz Silva Pegado- Subturma C 
  Etapa 3 e 4
*/

// https://editor.p5js.org
var x=100;
var y=400;
var yd=0;
var xd=0;
var estadoDisparo= false

function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(15);

ellipse(x, y, 70, 70)
  
x=x+5
if(x > width)
  x=0
  if(keyIsDown(UP_ARROW) && estadoDisparo == false){
  xd=x
  yd=y
  estadoDisparo= true;
  }
  if(estadoDisparo){
    ellipse(xd, yd, 10,10)
    yd=yd-15
    if(yd<0)
      estadoDisparo=false;
  }
}
  